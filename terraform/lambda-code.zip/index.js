var AWS = require('aws-sdk');
AWS.config.update({region: 'us-east-2'});


exports.handler = async (event) => {
  console.log(event)
    var ddb = new AWS.DynamoDB();
    
    var params = {
      TableName: 'user-data',
      Item: {
        'userID': { S: 'abcd' },
        'userData' : {M: {
            'firstName': {S: 'def'},
            'lastName': {S: 'ghi'}
        }}
      }
    };
    
    try {
        console.log("Invoked counter-test");

        const data = await ddb.putItem(params).promise();
        console.log(data);

        const response = {
            statusCode: 200,
            body: JSON.stringify('Record Inserted!'),
        };
        return response;      
    } catch (err) {
      console.log(err, err.stack);
      throw err;
    }
};
